﻿
using var game = new BetterJellyfish.BetterJellyfish();
game.Run();
