﻿
using var game = new Lab1_Napat_Phuwarintarawanich.Game1();
game.Run();
