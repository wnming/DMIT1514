﻿
using var game = new Lab2_Napat_Phuwarintarawanich.Game1();
game.Run();
