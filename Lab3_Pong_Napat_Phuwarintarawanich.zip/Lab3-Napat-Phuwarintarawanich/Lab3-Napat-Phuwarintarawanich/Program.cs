﻿
using var game = new Lab3_Napat_Phuwarintarawanich.Pong();
game.Run();
